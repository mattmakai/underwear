.. :changelog:

History
-------

0.4.0 (2013-12-26)
++++++++++++++++++
* Release now allows for 2 server web app deployments (one web server and
  one database server).
* Fixes issues with Supervisor template and Django environment variables.
* Includes templates required to tell the library where to deploy the 
  application.


0.3.0 (2013-12-24)
++++++++++++++++++
* First release on PyPI.


0.2.0 (2013-12-16)
++++++++++++++++++
* Added initial working Ansible scripts for deployment.


0.1.0 (2013-12-16)
++++++++++++++++++
* Initial codebase with Python package
