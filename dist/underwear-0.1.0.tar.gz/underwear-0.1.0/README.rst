===============================
Underwear
===============================

.. image:: https://badge.fury.io/py/underwear.png
    :target: http://badge.fury.io/py/underwear
    
.. image:: https://travis-ci.org/makaimc/underwear.png?branch=master
        :target: https://travis-ci.org/makaimc/underwear

.. image:: https://pypip.in/d/underwear/badge.png
        :target: https://crate.io/packages/underwear?version=latest


Automated deployments for Python-powered web applications

* Free software: MIT license
* Documentation: http://underwear.rtfd.org.

Features
--------

* TODO
