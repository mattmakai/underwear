.. :changelog:

History
-------

0.1.0 (2013-12-16)
++++++++++++++++++

* First release on PyPI.